<?php
    for ($i = 1; $i <= 10; $i++) {
        echo $i. "\n";
    }

    echo"<br/><hr/>";
    $n = 2;
    while ($n <= 10) {
        echo "$n \n";
        $n += 2;
    }
    echo "\n";
?>