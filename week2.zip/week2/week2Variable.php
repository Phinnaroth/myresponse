<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <div class="var">
        <?php
            $a = 4;
            $b = 5.1;
            $c = "Mystring";
            $d = true;
            echo"a=$a, b=$b, c=$c, d=$d";
        ?>
    </div>
</body>
</html>